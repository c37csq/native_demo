function Pipe() {
    //得到所有的参数（假设所有参数均为单参函数）
    var args = Array.prototype.slice.call(arguments);
    return function (data) {
        for (var i = 0; i < args.length; i++) {
            var func = args[i];
            data = func(data);
        }
        return data;
    }
}