/**
 * 科里化函数
 * @param {*} func 固定参数的函数
 */
function curry(func) {
    //获取剩余参数
    // var args = Array.from(arguments); //转换为真数组
    // args = args.slice(1); //从数组的第二项开始，取数组的剩余内容
    // 固定的参数
    var args = Array.prototype.slice.call(arguments, 1);
    return function () {
        //获取当前传入的参数
        var subArgs = Array.prototype.slice.call(arguments);
        var newArgs = args.concat(subArgs); //合并目前得到的所有参数
        //判断参数数量是否足够
        if (newArgs.length >= func.length) {
            //函数的length属性，表示该函数的形参数量
            return func.apply(null, newArgs);
        }
        else{
            //参数数量不够，继续科里化
            newArgs.unshift(func);//将func加入到数组的第一项
            return curry.apply(null, newArgs);
        }
    }
}